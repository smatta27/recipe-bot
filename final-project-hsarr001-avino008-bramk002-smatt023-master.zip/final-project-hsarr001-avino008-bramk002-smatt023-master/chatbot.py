from flask import Flask, render_template, request, session 
import os
import openai
import pyrebase
from flask import *

#Chatbot Code----------------------------------------------------------------------------------------------------------------------------
openai.api_key = "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"

app = Flask(__name__) 
app.secret_key =  b'\x8c\x10\x04\xaac\xf2\xbf\xb8\xa1\xb1~=\xa6\x86"\x95 '  #Change to a secure key

@app.before_request
def before_request():
    # Initialize chat history in session if not already present
    if 'chat_history' not in session:
        session['chat_history'] = []
# Function to check if the question is about recipes
def is_recipe_question(question):
    keywords = ['Hello', 'hello', 'Hi', 'hi', 'Goodbye', 
                'Bye', 'bye', 'thank you!', 'thank you', 'recipe', 
                'tutorial', 'frying', 'bake', 'make', 'dish', 'cook', 'serve', 'serving', 'ingredient', 
                'baking', 'cooking', 'kitchen', 'cuisine', 'fried']
    #checks if the current keywords are involved in the question. 
    return any(keyword in question.lower() for keyword in keywords) 

@app.route("/")     #app -> represents the web application, route -> routes it the html URL "/" url route to the chatbot page
def home():
    return render_template("mainpage.html")

@app.route("/chatbot_page", methods=["POST", "GET"])
def chatbot_page():
    return render_template("chatbot.html")

@app.route("/chatbot", methods=["POST"])
def chatbot():
    user_input = request.form["message"]
    if not is_recipe_question(user_input):
        bot_response = "I can only answer questions related to recipes. Please ask something related to cooking or recipes."
    else:
        prompt = f"User: {user_input}\nRECIPEBOT: "  #takes in user input and responds with CHATBOT 
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  # Update this to the model you're intending to use
            messages=[
                {"role": "user", "content": user_input}
            ]
        )
        bot_response = response['choices'][0]['message']['content']
    #Saving conversation between user and chatbot 
    session['chat_history'].append({"user": user_input, "bot": bot_response})
    session.modified = True
    return render_template("chatbot.html", user_input=user_input, bot_response=bot_response)

@app.route("/history")
def history():
    chat_history = session.get('chat_history', [])
    return render_template("history.html", chat_history=chat_history)

@app.route("/aboutus")
def AboutUs():
    return render_template("aboutus.html")

@app.route("/mainpage")
def mainpage():
    return render_template("mainpage.html")



if __name__ == "__main__":
    app.run(debug=True)